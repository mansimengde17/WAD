<?php
 header("Access-Control-Allow-Origin: *");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $class = $_POST['class'];
    $subject = $_POST['subject'];

    echo "Email : $email <br>
            Password: $password <br>
            Class : $class <br>
            Subject : $subject <br>";
} 
?>