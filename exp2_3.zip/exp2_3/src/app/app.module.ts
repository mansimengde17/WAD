import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProfileComponent } from './MyCompoents/profile/profile.component';
import { UserComponent } from './MyCompoents/user/user.component';
import { RegisterComponent } from './MyCompoents/register/register.component';
import { LoginComponent } from './MyCompoents/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateComponent } from './MyCompoents/update/update.component';

@NgModule({
  declarations: [
    AppComponent,
    ProfileComponent,
    UserComponent,
    RegisterComponent,
    LoginComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
