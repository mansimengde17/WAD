import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Profile } from '../../Profile'

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent {
  profiles:Profile[];
  currentStudentID: "";

  constructor( ){  
     this.profiles = [
      {
      userName: "student 1",
      userId: 1001,
      userPassword: "123",
      class: "TE IT"
      },
      {
        userName: "student 2",
        userId: 1002,
        userPassword: "adsf",
        class: "TE IT"
      },
      {
        userName: "student 3",
        userId: 1003,
        userPassword: "ewrq",
        class: "TE COMP"
      },
      {
        userName: "student 4",
        userId: 1004,
        userPassword: "RTYR",
        class: "TE ENTC"
      },
      {
        userName: "student 5",
        userId: 1005,
        userPassword: "123456",
        class: "TE IT"
      }
    ] 
  }
}