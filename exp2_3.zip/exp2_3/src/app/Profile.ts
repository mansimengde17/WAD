export class Profile{
    userName: string
    userId: number
    userPassword: string
    class: string
}